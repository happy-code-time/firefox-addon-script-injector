const version = '3.0.1';

const appName = 'Script Injector';

const appNameShort = 'Script Injector';

export {
    version,
    appName,
    appNameShort
};
