import * as React from 'react';

class ModuleNoFilteredData extends React.Component 
{
    render(){
        return (
            <div className="ModuleNoFilteredData">
                <div className="text">
                    🤯
                </div>
            </div>
        );
    }
};

export default ModuleNoFilteredData;