const version = '3.1.0';

const appName = 'Script Injector';

const appNameShort = 'Script Injector';

export {
    version,
    appName,
    appNameShort
};
