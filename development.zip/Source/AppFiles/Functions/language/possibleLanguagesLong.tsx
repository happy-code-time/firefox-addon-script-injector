const possibleLanguagesLong = [ 'Deutsch', 'English', 'Polski' ];
export default possibleLanguagesLong;