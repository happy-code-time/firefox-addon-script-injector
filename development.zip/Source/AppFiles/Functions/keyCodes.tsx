const keyCodes = {
    ENTER: 13
};

export default keyCodes;