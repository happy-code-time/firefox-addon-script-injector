export const colors = [
    'rgba(60,179,113,.8)',
    'rgba(0,123,255, .7)',
    'rgba(244,69,89,.7)',
    'rgba(30,144,255,.8)',
    'orange',
    'gold'
];